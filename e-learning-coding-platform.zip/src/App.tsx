import React, { useState, useEffect } from "react";
import { GraduationCap, Sparkles, BookOpen, Users, Star, Award, ChevronRight, Activity, Moon, Sun, Heart, RefreshCw } from "lucide-react";
import { Tutorial, Submission, Review } from "./types";
import { TutorialList } from "./components/TutorialList";
import { TutorialView } from "./components/TutorialView";
import { PeerReviewBoard } from "./components/PeerReviewBoard";
import { NewTutorialModal } from "./components/NewTutorialModal";

export default function App() {
  const [activeTab, setActiveTab] = useState<"tutorials" | "peer-review">("tutorials");
  const [tutorials, setTutorials] = useState<Tutorial[]>([]);
  const [submissions, setSubmissions] = useState<Submission[]>([]);
  const [activeTutorial, setActiveTutorial] = useState<Tutorial | null>(null);
  const [showGenerator, setShowGenerator] = useState(false);
  const [completedTutorials, setCompletedTutorials] = useState<string[]>([]);
  
  // Loading and error states
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Load all data on mount
  useEffect(() => {
    // Load progress from localStorage
    const savedProgress = localStorage.getItem("elearning_coding_progress");
    if (savedProgress) {
      try {
        setCompletedTutorials(JSON.parse(savedProgress));
      } catch (e) {
        console.error("Failed to parse progress from localStorage", e);
      }
    }

    loadData();
  }, []);

  const loadData = async () => {
    setIsLoading(true);
    setError(null);
    try {
      const [tutRes, subRes] = await Promise.all([
        fetch("/api/tutorials"),
        fetch("/api/submissions")
      ]);

      if (!tutRes.ok || !subRes.ok) {
        throw new Error("Could not fetch platform data from local server.");
      }

      const tuts = await tutRes.json();
      const subs = await subRes.json();

      setTutorials(tuts);
      setSubmissions(subs);
    } catch (err: any) {
      console.error(err);
      setError("Server connection offline. Please wait while the application boots.");
    } finally {
      setIsLoading(false);
    }
  };

  const handleTutorialCompleted = (tutorialId: string) => {
    if (!completedTutorials.includes(tutorialId)) {
      const updated = [...completedTutorials, tutorialId];
      setCompletedTutorials(updated);
      localStorage.setItem("elearning_coding_progress", JSON.stringify(updated));
    }
  };

  const handleTutorialCreated = (newTut: Tutorial) => {
    setTutorials((prev) => [...prev, newTut]);
    setActiveTutorial(newTut); // Auto open the freshly assembled tutorial!
  };

  const handleSubmissionSuccess = () => {
    // Reload feed, close playground drawer, switch to review board
    loadData();
    setActiveTutorial(null);
    setActiveTab("peer-review");
  };

  const handleAddReview = (submissionId: string, newReview: Review) => {
    setSubmissions((prevSubs) =>
      prevSubs.map((sub) => {
        if (sub.id === submissionId) {
          return {
            ...sub,
            reviews: [...(sub.reviews || []), newReview]
          };
        }
        return sub;
      })
    );
  };

  return (
    <div className="min-h-screen bg-[#F8FAFC] font-sans text-slate-900 antialiased flex flex-col">
      
      {/* Platform Top Header */}
      <nav className="h-16 bg-white border-b border-slate-200 px-6 sm:px-8 flex items-center justify-between shrink-0 sticky top-0 z-40">
        <div className="flex items-center gap-6">
          <div className="flex items-center gap-3 cursor-pointer" onClick={() => { setActiveTutorial(null); setActiveTab("tutorials"); }}>
            <div className="w-8 h-8 bg-indigo-600 rounded-lg flex items-center justify-center text-white font-bold text-sm shadow-sm shadow-indigo-100">
              C
            </div>
            <span className="font-bold text-lg tracking-tight text-slate-900">CodeFlow</span>
          </div>
          <div className="hidden md:block h-4 w-px bg-slate-200 mx-2"></div>
          <div className="hidden md:flex items-center gap-3 text-xs font-semibold text-slate-500 uppercase tracking-wider">
            <span>E-Learning Coding Campus</span>
          </div>
        </div>

        {/* Core Navigation Links */}
        <div className="hidden sm:flex items-center gap-1 bg-slate-100 p-1 rounded-lg border border-slate-200/60">
          <button
            onClick={() => { setActiveTutorial(null); setActiveTab("tutorials"); }}
            className={`px-4 py-1.5 rounded-md text-xs font-semibold transition-all cursor-pointer flex items-center gap-1.5 ${
              activeTab === "tutorials" && !activeTutorial
                ? "bg-white text-indigo-600 shadow-xs border border-slate-200/50"
                : "text-slate-500 hover:text-slate-800"
            }`}
          >
            <BookOpen className="w-3.5 h-3.5" />
            Course Catalog
          </button>
          <button
            onClick={() => { setActiveTutorial(null); setActiveTab("peer-review"); }}
            className={`px-4 py-1.5 rounded-md text-xs font-semibold transition-all cursor-pointer flex items-center gap-1.5 ${
              activeTab === "peer-review"
                ? "bg-white text-indigo-600 shadow-xs border border-slate-200/50"
                : "text-slate-500 hover:text-slate-800"
            }`}
          >
            <Users className="w-3.5 h-3.5" />
            Peer Review Board
          </button>
        </div>

        {/* User Progress Stats indicator */}
        <div className="flex items-center gap-4">
          <div className="bg-indigo-50 border border-indigo-100/80 px-3 py-1.5 rounded-lg flex items-center gap-2">
            <Award className="w-3.5 h-3.5 text-indigo-600" />
            <div className="text-left">
              <p className="text-[10px] font-bold text-indigo-600 uppercase tracking-widest leading-none">Passed</p>
              <p className="text-xs font-extrabold text-slate-900 leading-none mt-0.5">
                {completedTutorials.length} modules
              </p>
            </div>
          </div>
        </div>
      </nav>

      {/* Main Content Stage */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 min-h-0">
        {isLoading ? (
          <div className="py-24 flex flex-col items-center justify-center text-center space-y-4">
            <div className="w-12 h-12 border-4 border-indigo-100 border-t-indigo-600 rounded-full animate-spin"></div>
            <h3 className="font-bold text-gray-900 text-lg">Initializing Platform</h3>
            <p className="text-gray-500 text-sm max-w-sm leading-relaxed">
              Fetching curriculum indexes, standardizing code challenge modules, and setting up sandbox consoles...
            </p>
          </div>
        ) : error ? (
          <div className="max-w-md mx-auto py-24 text-center bg-white border border-gray-200 rounded-3xl p-8 space-y-4 shadow-sm">
            <div className="w-12 h-12 bg-rose-50 text-rose-600 rounded-2xl flex items-center justify-center mx-auto shadow-sm">
              <Activity className="w-6 h-6 animate-pulse" />
            </div>
            <h3 className="font-extrabold text-gray-900 text-lg">{error}</h3>
            <p className="text-gray-500 text-xs leading-relaxed">
              If this error persists, it usually means the custom Node.js backend is starting up or compiling. Press the reload button below to reconnect.
            </p>
            <button
              onClick={loadData}
              className="px-5 py-2.5 bg-indigo-600 text-white text-xs font-bold rounded-xl hover:bg-indigo-700 transition-colors cursor-pointer flex items-center gap-1.5 mx-auto"
            >
              <RefreshCw className="w-4 h-4" />
              Retry Connection
            </button>
          </div>
        ) : (
          <div className="h-full">
            
            {/* Active Tutorial view */}
            {activeTutorial ? (
              <TutorialView
                tutorial={activeTutorial}
                onBack={() => setActiveTutorial(null)}
                onSubmissionSuccess={handleSubmissionSuccess}
                onTutorialCompleted={handleTutorialCompleted}
              />
            ) : (
              <div>
                {/* Standard Tab Navigator for Mobile / Small Screens */}
                <div className="sm:hidden grid grid-cols-2 gap-2 mb-6 bg-gray-100 p-1.5 rounded-xl border border-gray-200/40">
                  <button
                    onClick={() => setActiveTab("tutorials")}
                    className={`py-2 rounded-lg text-xs font-bold text-center cursor-pointer ${
                      activeTab === "tutorials" ? "bg-white text-indigo-900 shadow-sm" : "text-gray-500"
                    }`}
                  >
                    Curriculum
                  </button>
                  <button
                    onClick={() => setActiveTab("peer-review")}
                    className={`py-2 rounded-lg text-xs font-bold text-center cursor-pointer ${
                      activeTab === "peer-review" ? "bg-white text-indigo-900 shadow-sm" : "text-gray-500"
                    }`}
                  >
                    Review Board
                  </button>
                </div>

                {/* Tab Switch Router */}
                {activeTab === "tutorials" ? (
                  <TutorialList
                    tutorials={tutorials}
                    onSelectTutorial={(tut) => setActiveTutorial(tut)}
                    onOpenGenerator={() => setShowGenerator(true)}
                    completedTutorials={completedTutorials}
                  />
                ) : (
                  <PeerReviewBoard
                    submissions={submissions}
                    onRefresh={loadData}
                    onAddReview={handleAddReview}
                  />
                )}
              </div>
            )}

          </div>
        )}
      </main>

      {/* Course Assembler Modal */}
      {showGenerator && (
        <NewTutorialModal
          onClose={() => setShowGenerator(false)}
          onTutorialCreated={handleTutorialCreated}
        />
      )}

      {/* Footer credits */}
      <footer className="bg-white border-t border-gray-100 py-6 mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-gray-400 font-medium">
          <p>© 2026 Sandbox Coding Campus. Powered by Gemini Generative AI.</p>
          <p className="flex items-center gap-1">
            Crafted for interactive tech literacy
            <Heart className="w-3 h-3 text-rose-500 fill-rose-500" />
          </p>
        </div>
      </footer>

    </div>
  );
}

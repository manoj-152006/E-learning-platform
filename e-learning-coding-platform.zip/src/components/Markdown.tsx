import React from "react";

interface MarkdownProps {
  children: string;
}

export function Markdown({ children }: MarkdownProps) {
  if (!children) return null;

  // Split text into paragraphs, headers, lists, and code blocks
  const parts = children.split(/(```[\s\S]*?```)/g);

  return (
    <div className="space-y-4 text-gray-700 leading-relaxed font-sans text-sm md:text-base">
      {parts.map((part, index) => {
        // Code block
        if (part.startsWith("```")) {
          const lines = part.split("\n");
          const language = lines[0].replace("```", "").trim();
          const code = lines.slice(1, lines.length - 1).join("\n");
          return (
            <div key={index} className="my-4 rounded-xl overflow-hidden border border-gray-200">
              <div className="bg-gray-100 px-4 py-1.5 text-xs font-mono text-gray-500 border-b border-gray-200 flex justify-between items-center">
                <span>{language || "code"}</span>
                <span className="text-[10px] uppercase tracking-wider font-semibold">Playground Compatible</span>
              </div>
              <pre className="bg-gray-900 text-gray-100 p-4 overflow-x-auto font-mono text-xs leading-5">
                <code>{code}</code>
              </pre>
            </div>
          );
        }

        // Standard text lines
        const lines = part.split("\n");
        return (
          <div key={index} className="space-y-2">
            {lines.map((line, lineIndex) => {
              const trimmed = line.trim();
              if (!trimmed) return null;

              // Headers
              if (trimmed.startsWith("### ")) {
                return (
                  <h3 key={lineIndex} className="text-lg font-semibold text-gray-900 mt-6 mb-2 tracking-tight">
                    {parseInlineMarkdown(trimmed.substring(4))}
                  </h3>
                );
              }
              if (trimmed.startsWith("## ")) {
                return (
                  <h2 key={lineIndex} className="text-xl font-bold text-gray-900 mt-8 mb-3 tracking-tight border-b border-gray-100 pb-1">
                    {parseInlineMarkdown(trimmed.substring(3))}
                  </h2>
                );
              }
              if (trimmed.startsWith("# ")) {
                return (
                  <h1 key={lineIndex} className="text-2xl font-extrabold text-gray-900 mt-10 mb-4 tracking-tight">
                    {parseInlineMarkdown(trimmed.substring(2))}
                  </h1>
                );
              }

              // Lists
              if (trimmed.startsWith("- ") || trimmed.startsWith("* ")) {
                return (
                  <ul key={lineIndex} className="list-disc list-inside pl-4 text-gray-700 space-y-1">
                    <li>{parseInlineMarkdown(trimmed.substring(2))}</li>
                  </ul>
                );
              }

              // Ordered Lists
              const orderedListMatch = trimmed.match(/^(\d+)\.\s(.*)/);
              if (orderedListMatch) {
                return (
                  <ol key={lineIndex} className="list-decimal list-inside pl-4 text-gray-700 space-y-1">
                    <li>{parseInlineMarkdown(orderedListMatch[2])}</li>
                  </ol>
                );
              }

              // Blockquote
              if (trimmed.startsWith("> ")) {
                return (
                  <blockquote key={lineIndex} className="border-l-4 border-indigo-500 bg-indigo-50/50 p-4 rounded-r-xl my-4 text-indigo-900 font-medium italic">
                    {parseInlineMarkdown(trimmed.substring(2))}
                  </blockquote>
                );
              }

              // Normal paragraph
              return (
                <p key={lineIndex} className="text-gray-600 leading-relaxed">
                  {parseInlineMarkdown(trimmed)}
                </p>
              );
            })}
          </div>
        );
      })}
    </div>
  );
}

// Simple inline parser for **bold**, *italic*, and `inline code`
function parseInlineMarkdown(text: string) {
  // Regex to match bold, italic, inline code
  const tokens = text.split(/(\*\*.*?\*\*|\*.*?\*|`.*?`)/g);

  return tokens.map((token, index) => {
    if (token.startsWith("**") && token.endsWith("**")) {
      return (
        <strong key={index} className="font-semibold text-gray-900">
          {token.substring(2, token.length - 2)}
        </strong>
      );
    }
    if (token.startsWith("*") && token.endsWith("*")) {
      return (
        <em key={index} className="italic text-gray-800">
          {token.substring(1, token.length - 1)}
        </em>
      );
    }
    if (token.startsWith("`") && token.endsWith("`")) {
      return (
        <code key={index} className="font-mono text-xs px-1.5 py-0.5 bg-gray-100 border border-gray-200 text-rose-600 rounded">
          {token.substring(1, token.length - 1)}
        </code>
      );
    }
    return token;
  });
}

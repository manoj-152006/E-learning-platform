import React, { useState } from "react";
import { Sparkles, X, BookOpen, AlertCircle, RefreshCw } from "lucide-react";
import { Tutorial } from "../types";

interface NewTutorialModalProps {
  onClose: () => void;
  onTutorialCreated: (tutorial: Tutorial) => void;
}

const PROGRESS_MESSAGES = [
  "Formulating training syllabus...",
  "Drafting learning chapters with diagrams...",
  "Writing code sandbox challenge template...",
  "Structuring multiple-choice concept checks...",
  "Validating code examples and solutions...",
  "Saving your custom tutorial to the curriculum..."
];

export function NewTutorialModal({ onClose, onTutorialCreated }: NewTutorialModalProps) {
  const [topic, setTopic] = useState("");
  const [difficulty, setDifficulty] = useState<"Beginner" | "Intermediate" | "Advanced">("Intermediate");
  const [isGenerating, setIsGenerating] = useState(false);
  const [progressIdx, setProgressIdx] = useState(0);
  const [error, setError] = useState<string | null>(null);

  // Rotate progress messages during generation
  React.useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isGenerating) {
      interval = setInterval(() => {
        setProgressIdx((prev) => (prev + 1) % PROGRESS_MESSAGES.length);
      }, 3000);
    }
    return () => clearInterval(interval);
  }, [isGenerating]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!topic.trim()) return;

    setIsGenerating(true);
    setProgressIdx(0);
    setError(null);

    try {
      const res = await fetch("/api/tutorials/generate-ai", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ topic, difficulty }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || "Failed to generate tutorial");
      }

      onTutorialCreated(data);
      onClose();
    } catch (err: any) {
      console.error(err);
      setError(err.message || "An unexpected error occurred during tutorial generation.");
      setIsGenerating(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/45 backdrop-blur-xs animate-fade-in">
      <div className="bg-white rounded-xl w-full max-w-lg overflow-hidden shadow-xl border border-slate-200 flex flex-col">
        {/* Header */}
        <div className="px-6 py-4 bg-slate-50 border-b border-slate-200/60 flex justify-between items-center">
          <div className="flex items-center gap-2">
            <div className="p-1.5 bg-indigo-50 text-indigo-600 rounded-lg border border-indigo-100">
              <Sparkles className="w-4 h-4 fill-indigo-100" />
            </div>
            <h3 className="font-extrabold text-slate-900 tracking-tight text-sm uppercase tracking-wider">AI Tutorial Architect</h3>
          </div>
          {!isGenerating && (
            <button
              onClick={onClose}
              className="text-slate-400 hover:text-slate-600 hover:bg-slate-100 p-1.5 rounded-lg transition-colors cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Content */}
        <div className="p-6 flex-1 overflow-y-auto">
          {isGenerating ? (
            <div className="py-8 flex flex-col items-center justify-center text-center">
              <div className="relative mb-6">
                <div className="w-12 h-12 border-4 border-indigo-100 border-t-indigo-600 rounded-full animate-spin"></div>
                <div className="absolute inset-0 flex items-center justify-center">
                  <Sparkles className="w-5 h-5 text-indigo-500 animate-pulse" />
                </div>
              </div>
              <h4 className="text-slate-900 font-bold text-base mb-1">Architecting Custom Tutorial</h4>
              <p className="text-indigo-600 font-mono text-xs tracking-wide h-6 animate-pulse">
                {PROGRESS_MESSAGES[progressIdx]}
              </p>
              <p className="text-slate-400 text-[11px] mt-6 max-w-xs leading-relaxed">
                Our Gemini-Powered Tutorial Architect is structuring chapters, compiling a sandbox exercise, and drafting quizzes. This may take 10-15 seconds.
              </p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-5">
              <div>
                <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-2">
                  What do you want to learn today?
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. SQL Database Joins, Rust Memory Ownership, CSS Flexbox & Grid..."
                  value={topic}
                  onChange={(e) => setTopic(e.target.value)}
                  className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 focus:border-indigo-500 focus:bg-white focus:ring-1 focus:ring-indigo-500 rounded-lg outline-none font-sans text-slate-800 transition-colors text-xs"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-2">
                  Select Target Difficulty Level
                </label>
                <div className="grid grid-cols-3 gap-3">
                  {(["Beginner", "Intermediate", "Advanced"] as const).map((level) => (
                    <button
                      key={level}
                      type="button"
                      onClick={() => setDifficulty(level)}
                      className={`py-2 px-2 text-xs font-semibold rounded-lg border transition-colors flex flex-col items-center justify-center cursor-pointer ${
                        difficulty === level
                          ? "bg-indigo-50 text-indigo-700 border-indigo-200"
                          : "bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100"
                      }`}
                    >
                      <span>{level}</span>
                    </button>
                  ))}
                </div>
              </div>

              {error && (
                <div className="p-4 bg-rose-50 border border-rose-100 rounded-lg flex gap-2.5 items-start text-rose-900">
                  <AlertCircle className="w-4 h-4 shrink-0 text-rose-600 mt-0.5" />
                  <div className="text-xs space-y-1">
                    <p className="font-bold">Generation Failed</p>
                    <p className="text-rose-700 leading-relaxed">{error}</p>
                  </div>
                </div>
              )}

              <div className="pt-3 flex gap-3">
                <button
                  type="button"
                  onClick={onClose}
                  className="flex-1 py-2 border border-slate-200 text-slate-700 font-semibold rounded-lg text-xs hover:bg-slate-50 transition-colors cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={!topic.trim()}
                  className="flex-1 py-2 bg-indigo-600 text-white font-semibold rounded-lg text-xs hover:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors shadow-sm flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <Sparkles className="w-3.5 h-3.5 fill-indigo-200" />
                  Assemble with AI
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}

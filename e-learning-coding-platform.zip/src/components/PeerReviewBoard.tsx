import React, { useState, useEffect } from "react";
import { Users, Star, Sparkles, MessageSquare, Clock, Code, AlertCircle, RefreshCw, Send, CheckCircle2 } from "lucide-react";
import { Submission, Review } from "../types";
import { Markdown } from "./Markdown";

interface PeerReviewBoardProps {
  submissions: Submission[];
  onRefresh: () => void;
  onAddReview: (submissionId: string, review: Review) => void;
}

export function PeerReviewBoard({ submissions, onRefresh, onAddReview }: PeerReviewBoardProps) {
  const [selectedSub, setSelectedSub] = useState<Submission | null>(null);
  const [searchQuery, setSearchQuery] = useState("");

  // Review form state
  const [reviewerName, setReviewerName] = useState("");
  const [comments, setComments] = useState("");
  const [ratingCorrectness, setRatingCorrectness] = useState(5);
  const [ratingReadability, setRatingReadability] = useState(5);
  const [ratingArchitecture, setRatingArchitecture] = useState(5);
  const [isSubmittingReview, setIsSubmittingReview] = useState(false);

  // AI Review request state
  const [isRequestingAI, setIsRequestingAI] = useState(false);
  const [aiProgressMsg, setAiProgressMsg] = useState("");

  // Select first submission automatically on load if none selected
  useEffect(() => {
    if (submissions.length > 0 && !selectedSub) {
      setSelectedSub(submissions[0]);
    } else if (selectedSub) {
      // Keep selected submission updated when new reviews are loaded
      const updated = submissions.find((s) => s.id === selectedSub.id);
      if (updated) setSelectedSub(updated);
    }
  }, [submissions, selectedSub]);

  // Handle AI Review cycle
  const handleRequestAIReview = async () => {
    if (!selectedSub) return;

    setIsRequestingAI(true);
    setAiProgressMsg("Reviewing code structures...");

    const intervals = [
      "Analyzing algorithm correctness...",
      "Assessing styling and readability index...",
      "Drafting architecture suggestions...",
      "Formatting review comments in Markdown..."
    ];

    let currentStep = 0;
    const progressTimer = setInterval(() => {
      if (currentStep < intervals.length) {
        setAiProgressMsg(intervals[currentStep]);
        currentStep++;
      }
    }, 2500);

    try {
      const res = await fetch(`/api/submissions/${selectedSub.id}/reviews/ai`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || "Failed to generate AI review");
      }

      onAddReview(selectedSub.id, data);
      setComments("");
    } catch (err: any) {
      console.error(err);
      alert(err.message || "Could not complete AI review. Verify API key is added.");
    } finally {
      clearInterval(progressTimer);
      setIsRequestingAI(false);
      setAiProgressMsg("");
    }
  };

  // Submit standard manual peer review
  const handleSubmitReview = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedSub || !reviewerName.trim() || !comments.trim()) return;

    setIsSubmittingReview(true);
    try {
      const res = await fetch(`/api/submissions/${selectedSub.id}/reviews`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          reviewerName: reviewerName.trim(),
          ratingCorrectness,
          ratingReadability,
          ratingArchitecture,
          comments: comments.trim()
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || "Failed to submit review");
      }

      onAddReview(selectedSub.id, data);
      setComments("");
      setReviewerName("");
    } catch (err: any) {
      console.error(err);
      alert("Failed to submit review.");
    } finally {
      setIsSubmittingReview(false);
    }
  };

  const filteredSubmissions = submissions.filter((sub) =>
    sub.userName.toLowerCase().includes(searchQuery.toLowerCase()) ||
    sub.tutorialTitle.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 h-[calc(100vh-6.5rem)] overflow-hidden animate-fade-in">
      
      {/* Left List Pane: Submissions list */}
      <div className="lg:col-span-4 bg-white rounded-xl border border-slate-200 shadow-sm flex flex-col overflow-hidden">
        <div className="p-4 bg-slate-50 border-b border-slate-200/60 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Users className="w-4 h-4 text-indigo-600" />
            <h3 className="font-extrabold text-slate-900 tracking-tight text-xs uppercase tracking-wider">Submission Feed</h3>
          </div>
          <button
            onClick={onRefresh}
            className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
            title="Refresh feed"
          >
            <RefreshCw className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Filter Input */}
        <div className="p-3 border-b border-slate-100 bg-white">
          <input
            type="text"
            placeholder="Search submissions..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full px-3 py-1.5 text-xs bg-slate-50 border border-slate-200 focus:border-indigo-500 focus:bg-white rounded-lg outline-none text-slate-700 transition-colors"
          />
        </div>

        {/* Submissions List */}
        <div className="flex-1 overflow-y-auto divide-y divide-slate-100 bg-white">
          {filteredSubmissions.length === 0 ? (
            <div className="py-12 px-4 text-center">
              <MessageSquare className="w-10 h-10 text-slate-300 mx-auto mb-2" />
              <p className="text-slate-400 text-xs">No sandbox solutions submitted yet. Be the first to publish!</p>
            </div>
          ) : (
            filteredSubmissions.map((sub) => {
              const isSelected = selectedSub?.id === sub.id;
              const formattedDate = new Date(sub.createdAt).toLocaleDateString(undefined, {
                month: "short",
                day: "numeric",
                hour: "2-digit",
                minute: "2-digit"
              });

              return (
                <button
                  key={sub.id}
                  onClick={() => setSelectedSub(sub)}
                  className={`w-full text-left p-4 hover:bg-slate-50 transition-colors flex flex-col gap-1 border-l-4 cursor-pointer ${
                    isSelected ? "bg-indigo-50/25 border-indigo-600" : "border-transparent"
                  }`}
                >
                  <div className="flex justify-between items-start gap-2">
                    <span className="font-bold text-slate-900 text-xs tracking-tight line-clamp-1">{sub.userName}</span>
                    <span className="text-[10px] text-slate-400 flex items-center gap-1 shrink-0 font-medium">
                      <Clock className="w-3 h-3" />
                      {formattedDate}
                    </span>
                  </div>

                  <span className="text-slate-500 text-[11px] font-medium line-clamp-1">{sub.tutorialTitle}</span>

                  <div className="mt-2 flex items-center justify-between text-[10px] text-slate-400">
                    <span className="flex items-center gap-1 font-semibold text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded">
                      <MessageSquare className="w-3 h-3 text-indigo-500" />
                      {sub.reviews?.length || 0} reviews
                    </span>
                    {sub.reviews?.some((r) => r.isAI) && (
                      <span className="flex items-center gap-0.5 text-indigo-700 font-bold bg-indigo-50 px-2 py-0.5 rounded border border-indigo-100">
                        <Sparkles className="w-3 h-3 text-indigo-500 fill-indigo-200" />
                        AI Reviewed
                      </span>
                    )}
                  </div>
                </button>
              );
            })
          )}
        </div>
      </div>


      {/* Right Details Pane: View code and add reviews */}
      <div className="lg:col-span-8 bg-white rounded-xl border border-slate-200 shadow-sm flex flex-col overflow-hidden">
        {selectedSub ? (
          <div className="flex-1 flex flex-col min-h-0">
            {/* Detail Header */}
            <div className="px-6 py-4 bg-slate-50 border-b border-slate-200/60 flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div>
                <p className="text-[10px] font-bold text-indigo-600 tracking-wider uppercase">Submission Workspace</p>
                <h3 className="font-extrabold text-slate-900 tracking-tight text-sm mt-0.5">
                  Reviewing {selectedSub.userName}'s code
                </h3>
              </div>

              {/* AI Trigger */}
              <button
                onClick={handleRequestAIReview}
                disabled={isRequestingAI || selectedSub.reviews.some(r => r.isAI)}
                className="px-4 py-2 bg-indigo-600 text-white font-semibold text-xs rounded-lg hover:bg-indigo-700 disabled:bg-slate-50 disabled:text-slate-400 disabled:border-slate-200 border border-transparent disabled:cursor-not-allowed transition-colors shadow-sm flex items-center gap-1.5 cursor-pointer"
              >
                <Sparkles className="w-3.5 h-3.5 fill-indigo-200" />
                {selectedSub.reviews.some(r => r.isAI) ? "AI Review Complete" : "Query AI Code Mentor"}
              </button>
            </div>

            {/* Main Content Area */}
            <div className="flex-1 p-6 overflow-y-auto min-h-0 space-y-6">
              
              {/* AI loading state */}
              {isRequestingAI && (
                <div className="p-6 bg-indigo-50/30 border border-indigo-100 rounded-lg flex flex-col items-center justify-center text-center space-y-3">
                  <div className="w-10 h-10 border-4 border-indigo-100 border-t-indigo-600 rounded-full animate-spin"></div>
                  <h4 className="font-bold text-slate-900 text-sm">AI Mentor Review in Progress</h4>
                  <p className="text-indigo-600 font-mono text-xs tracking-wide animate-pulse">{aiProgressMsg}</p>
                </div>
              )}

              {/* Code Sandbox View */}
              <div className="space-y-2">
                <div className="flex justify-between items-center bg-slate-50 p-3 rounded-lg border border-slate-200/60">
                  <span className="text-xs font-bold text-slate-600 flex items-center gap-1">
                    <Code className="w-4 h-4 text-indigo-600" />
                    Submitted Playground Code
                  </span>
                  <span className="text-[10px] text-slate-400 font-mono">language: TypeScript</span>
                </div>
                <div className="rounded-lg overflow-hidden border border-slate-200 shadow-sm">
                  <pre className="bg-slate-950 text-slate-200 p-4 font-mono text-xs overflow-x-auto leading-relaxed max-h-72 border border-slate-800">
                    <code>{selectedSub.submittedCode}</code>
                  </pre>
                </div>
              </div>

              {/* Student Notes */}
              {selectedSub.userNotes && (
                <div className="p-4 bg-slate-50 border border-slate-200 rounded-lg">
                  <h4 className="text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1">Student Notes / Thoughts</h4>
                  <p className="text-slate-600 text-xs leading-relaxed italic">"{selectedSub.userNotes}"</p>
                </div>
              )}

              {/* Reviews timeline */}
              <div className="space-y-4 pt-4 border-t border-slate-100">
                <h4 className="font-bold text-slate-900 text-xs uppercase tracking-wider flex items-center gap-1.5">
                  <MessageSquare className="w-4 h-4 text-indigo-600" />
                  Code Evaluation Timeline ({selectedSub.reviews?.length || 0})
                </h4>

                <div className="space-y-4">
                  {selectedSub.reviews && selectedSub.reviews.length > 0 ? (
                    selectedSub.reviews.map((rev) => (
                      <div
                        key={rev.id}
                        className={`p-5 rounded-lg border ${
                          rev.isAI
                            ? "bg-indigo-50/20 border-indigo-100"
                            : "bg-white border-slate-200"
                        }`}
                      >
                        {/* Reviewer Meta */}
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-100">
                          <div className="flex items-center gap-1.5">
                            {rev.isAI ? (
                              <div className="p-1 bg-indigo-100 text-indigo-700 rounded">
                                <Sparkles className="w-3.5 h-3.5 fill-indigo-200" />
                              </div>
                            ) : (
                              <div className="w-2 h-2 rounded-full bg-emerald-500"></div>
                            )}
                            <span className="font-bold text-slate-900 text-xs">{rev.reviewerName}</span>
                            {rev.isAI && (
                              <span className="text-[9px] bg-indigo-100 text-indigo-800 font-bold px-1.5 py-0.5 rounded">
                                Official AI Feedback
                              </span>
                            )}
                          </div>
                          <span className="text-[10px] text-slate-400 font-medium">
                            {new Date(rev.createdAt).toLocaleDateString()}
                          </span>
                        </div>

                        {/* Ratings */}
                        <div className="grid grid-cols-3 gap-4 py-3 text-center border-b border-slate-100">
                          <div>
                            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Correctness</p>
                            <p className="text-xs font-black text-slate-900 font-mono mt-0.5 flex items-center justify-center gap-1">
                              {rev.ratingCorrectness}/5
                              <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                            </p>
                          </div>
                          <div>
                            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Readability</p>
                            <p className="text-xs font-black text-slate-900 font-mono mt-0.5 flex items-center justify-center gap-1">
                              {rev.ratingReadability}/5
                              <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                            </p>
                          </div>
                          <div>
                            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Architecture</p>
                            <p className="text-xs font-black text-slate-900 font-mono mt-0.5 flex items-center justify-center gap-1">
                              {rev.ratingArchitecture}/5
                              <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                            </p>
                          </div>
                        </div>

                        {/* Comments comments */}
                        <div className="prose max-w-none pt-3 text-xs leading-relaxed text-slate-600">
                          <Markdown>{rev.comments}</Markdown>
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="text-center p-6 bg-slate-50 rounded-lg border border-dashed border-slate-200">
                      <p className="text-slate-400 text-xs">No feedback submitted yet. Request AI or write a review below.</p>
                    </div>
                  )}
                </div>
              </div>

              {/* Submit Peer Review Form */}
              <div className="bg-slate-50 border border-slate-200 p-5 rounded-lg space-y-4">
                <h4 className="font-bold text-slate-900 text-xs flex items-center gap-1.5 uppercase tracking-wider text-slate-400">
                  <Send className="w-3.5 h-3.5 text-indigo-500" />
                  Evaluate Solution & Publish Review
                </h4>

                <form onSubmit={handleSubmitReview} className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1">
                        Your Peer Display Name
                      </label>
                      <input
                        type="text"
                        required
                        placeholder="e.g. CodeCritic_42"
                        value={reviewerName}
                        onChange={(e) => setReviewerName(e.target.value)}
                        className="w-full px-3 py-2 bg-white border border-slate-200 focus:border-indigo-500 rounded-lg outline-none font-sans text-xs text-slate-800 transition-colors"
                      />
                    </div>
                  </div>

                  {/* Rating meters */}
                  <div className="grid grid-cols-3 gap-4">
                    <div>
                      <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1">
                        Correctness (1-5)
                      </label>
                      <input
                        type="range"
                        min="1"
                        max="5"
                        value={ratingCorrectness}
                        onChange={(e) => setRatingCorrectness(Number(e.target.value))}
                        className="w-full accent-indigo-600"
                      />
                      <div className="flex justify-between text-[10px] text-slate-400 font-mono mt-0.5">
                        <span>Broken</span>
                        <span className="font-bold text-slate-700">{ratingCorrectness}/5</span>
                        <span>Perfect</span>
                      </div>
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1">
                        Readability (1-5)
                      </label>
                      <input
                        type="range"
                        min="1"
                        max="5"
                        value={ratingReadability}
                        onChange={(e) => setRatingReadability(Number(e.target.value))}
                        className="w-full accent-indigo-600"
                      />
                      <div className="flex justify-between text-[10px] text-slate-400 font-mono mt-0.5">
                        <span>Messy</span>
                        <span className="font-bold text-slate-700">{ratingReadability}/5</span>
                        <span>Clean</span>
                      </div>
                    </div>
                    <div>
                      <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1">
                        Architecture (1-5)
                      </label>
                      <input
                        type="range"
                        min="1"
                        max="5"
                        value={ratingArchitecture}
                        onChange={(e) => setRatingArchitecture(Number(e.target.value))}
                        className="w-full accent-indigo-600"
                      />
                      <div className="flex justify-between text-[10px] text-slate-400 font-mono mt-0.5">
                        <span>Poor</span>
                        <span className="font-bold text-slate-700">{ratingArchitecture}/5</span>
                        <span>Optimal</span>
                      </div>
                    </div>
                  </div>

                  <div>
                    <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1">
                      Constructive Comments (Markdown supported)
                    </label>
                    <textarea
                      required
                      placeholder="Write feedback... What did they do well? What can be optimized? Be supportive!"
                      value={comments}
                      onChange={(e) => setComments(e.target.value)}
                      rows={3}
                      className="w-full px-3 py-2 bg-white border border-slate-200 focus:border-indigo-500 rounded-lg outline-none font-sans text-xs text-slate-800 resize-none transition-colors"
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={isSubmittingReview || !reviewerName.trim() || !comments.trim()}
                    className="w-full py-2 bg-indigo-600 text-white hover:bg-indigo-700 disabled:opacity-50 rounded-lg text-xs font-semibold transition-colors shadow-sm flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    {isSubmittingReview ? "Publishing Review..." : "Publish Peer Review"}
                  </button>
                </form>
              </div>

            </div>
          </div>
        ) : (
          <div className="flex-1 flex flex-col items-center justify-center p-12 text-center text-slate-400">
            <Users className="w-12 h-12 text-slate-200 mb-3 animate-pulse" />
            <h4 className="font-bold text-slate-900 text-sm mb-1">No Submission Selected</h4>
            <p className="text-slate-400 text-xs">Select a student submission from the feed list to audit and review their solution.</p>
          </div>
        )}
      </div>

    </div>
  );
}

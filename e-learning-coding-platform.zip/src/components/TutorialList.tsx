import React, { useState, useMemo } from "react";
import { Search, Sparkles, BookOpen, Clock, ChevronRight, GraduationCap } from "lucide-react";
import { Tutorial } from "../types";

interface TutorialListProps {
  tutorials: Tutorial[];
  onSelectTutorial: (tutorial: Tutorial) => void;
  onOpenGenerator: () => void;
  completedTutorials: string[]; // List of completed tutorial IDs
}

export function TutorialList({ tutorials, onSelectTutorial, onOpenGenerator, completedTutorials }: TutorialListProps) {
  const [search, setSearch] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("All");

  // Dynamically compute active categories based on tutorials
  const categories = useMemo(() => {
    const list = new Set<string>();
    tutorials.forEach((t) => {
      if (t.category) list.add(t.category);
    });
    return ["All", ...Array.from(list)];
  }, [tutorials]);

  // Filter tutorials
  const filteredTutorials = useMemo(() => {
    return tutorials.filter((t) => {
      const matchesSearch =
        t.title.toLowerCase().includes(search.toLowerCase()) ||
        t.description.toLowerCase().includes(search.toLowerCase()) ||
        t.category.toLowerCase().includes(search.toLowerCase());
      const matchesCategory = selectedCategory === "All" || t.category === selectedCategory;
      return matchesSearch && matchesCategory;
    });
  }, [tutorials, search, selectedCategory]);

  return (
    <div className="space-y-8 animate-fade-in">
      {/* Hero Welcome Board */}
      <div className="relative bg-white border border-slate-200 rounded-2xl p-6 md:p-8 text-slate-900 overflow-hidden shadow-sm">
        <div className="absolute right-0 bottom-0 top-0 opacity-5 flex items-center justify-center pointer-events-none pr-8">
          <GraduationCap className="w-64 h-64 text-indigo-900" />
        </div>

        <div className="relative max-w-xl space-y-4">
          <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 bg-indigo-50 border border-indigo-100 text-indigo-700 rounded-md text-[10px] font-bold uppercase tracking-wider">
            <Sparkles className="w-3 h-3 text-indigo-500 animate-pulse" />
            AI-Augmented Sandbox Learning
          </div>
          <h2 className="text-2xl md:text-3xl font-extrabold tracking-tight text-slate-900 leading-tight">
            Curated Coding Modules & Custom AI Curriculums
          </h2>
          <p className="text-slate-500 text-xs md:text-sm leading-relaxed">
            Master development hands-on. Compile code sandbox challenges, complete conceptual check-ups, review student code, or build bespoke custom coding tutorials dynamically using Generative AI.
          </p>

          <button
            onClick={onOpenGenerator}
            className="inline-flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white text-xs font-semibold rounded-lg hover:bg-indigo-700 transition-colors shadow-sm shadow-indigo-100 cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5 fill-indigo-200 text-white" />
            Architect Custom AI Course
          </button>
        </div>
      </div>

      {/* Toolbar & Filters */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        {/* Category Pills */}
        <div className="flex flex-wrap items-center gap-1.5">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg border transition-colors cursor-pointer ${
                selectedCategory === cat
                  ? "bg-indigo-50 text-indigo-700 border-indigo-200"
                  : "bg-white text-slate-600 border-slate-200 hover:bg-slate-50 hover:text-slate-900"
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Search */}
        <div className="relative w-full md:w-80">
          <Search className="absolute left-3 top-2.5 w-4 h-4 text-slate-400" />
          <input
            type="text"
            placeholder="Search tutorials..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-4 py-2 text-xs bg-white border border-slate-200 focus:border-indigo-500 rounded-lg outline-none text-slate-700 transition-colors shadow-xs"
          />
        </div>
      </div>

      {/* Grid of Tutorials */}
      {filteredTutorials.length === 0 ? (
        <div className="bg-white rounded-xl border border-slate-200 p-12 text-center max-w-md mx-auto shadow-xs">
          <BookOpen className="w-10 h-10 text-slate-300 mx-auto mb-3" />
          <h4 className="font-bold text-slate-900 text-base mb-1">No tutorials match your query</h4>
          <p className="text-slate-400 text-xs mb-4">
            Try resetting your search query, choosing another category, or generate a brand new course on this topic!
          </p>
          <button
            onClick={onOpenGenerator}
            className="px-4 py-2 bg-indigo-600 text-white text-xs font-semibold rounded-lg hover:bg-indigo-700 transition-colors cursor-pointer inline-flex items-center gap-1.5"
          >
            <Sparkles className="w-3.5 h-3.5 text-indigo-200" />
            Assemble custom AI course
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredTutorials.map((tut) => {
            const isCompleted = completedTutorials.includes(tut.id);
            return (
              <div
                key={tut.id}
                className="group relative bg-white rounded-xl border border-slate-200 hover:border-indigo-400 hover:shadow-xs p-5 transition-all flex flex-col justify-between"
              >
                {/* AI Tag */}
                {tut.isAICreated && (
                  <span className="absolute -top-2.5 right-4 inline-flex items-center gap-1 px-2 py-0.5 bg-indigo-50 text-indigo-700 border border-indigo-100 rounded-md text-[9px] font-bold uppercase tracking-wider">
                    <Sparkles className="w-2.5 h-2.5 text-indigo-600 fill-indigo-200" />
                    AI Architected
                  </span>
                )}

                <div className="space-y-3">
                  <div className="flex items-center justify-between gap-2">
                    <span className="px-2 py-0.5 bg-slate-100 text-slate-600 rounded text-[9px] font-bold uppercase tracking-wider">
                      {tut.category}
                    </span>
                    <span
                      className={`text-[9px] font-bold uppercase tracking-wider ${
                        tut.difficulty === "Beginner"
                          ? "text-emerald-600"
                          : tut.difficulty === "Intermediate"
                            ? "text-amber-600"
                            : "text-rose-600"
                      }`}
                    >
                      {tut.difficulty}
                    </span>
                  </div>

                  <div className="space-y-1">
                    <h3 className="font-bold text-slate-900 group-hover:text-indigo-600 text-sm leading-snug transition-colors line-clamp-1">
                      {tut.title}
                    </h3>
                    <p className="text-slate-500 text-xs leading-relaxed line-clamp-2">
                      {tut.description}
                    </p>
                  </div>
                </div>

                <div className="mt-5 pt-3.5 border-t border-slate-100 flex items-center justify-between gap-2">
                  <div className="flex items-center gap-3 text-slate-400 font-semibold text-[11px]">
                    <div className="flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5 text-slate-300" />
                      <span>{tut.duration}</span>
                    </div>
                    {isCompleted && (
                      <span className="text-emerald-600 font-bold flex items-center gap-1 bg-emerald-50 px-2 py-0.5 rounded text-[9px]">
                        ✓ Quiz Passed
                      </span>
                    )}
                  </div>

                  <button
                    onClick={() => onSelectTutorial(tut)}
                    className="inline-flex items-center justify-center w-8 h-8 rounded-lg bg-slate-50 group-hover:bg-indigo-600 text-slate-400 group-hover:text-white transition-colors cursor-pointer"
                  >
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

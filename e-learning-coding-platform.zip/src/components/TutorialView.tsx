import React, { useState, useEffect } from "react";
import { ChevronLeft, ChevronRight, Play, RefreshCw, Send, CheckCircle2, AlertCircle, BookOpen, GraduationCap, Code } from "lucide-react";
import { Tutorial } from "../types";
import { Markdown } from "./Markdown";

interface TutorialViewProps {
  tutorial: Tutorial;
  onBack: () => void;
  onSubmissionSuccess: () => void;
  onTutorialCompleted: (tutorialId: string) => void;
}

export function TutorialView({ tutorial, onBack, onSubmissionSuccess, onTutorialCompleted }: TutorialViewProps) {
  const [activeChapterIdx, setActiveChapterIdx] = useState(0);
  const [sandboxCode, setSandboxCode] = useState(tutorial.codeTemplate);
  const [consoleOutput, setConsoleOutput] = useState<string[]>([]);
  const [isRunning, setIsRunning] = useState(false);

  // Submission Form State
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [userName, setUserName] = useState("");
  const [userNotes, setUserNotes] = useState("");
  const [showSubmitForm, setShowSubmitForm] = useState(false);
  const [submitSuccess, setSubmitSuccess] = useState(false);

  // Quiz State
  const [selectedAnswers, setSelectedAnswers] = useState<{ [qId: string]: number }>({});
  const [checkedQuestions, setCheckedQuestions] = useState<{ [qId: string]: boolean }>({});
  const [quizSubmitted, setQuizSubmitted] = useState(false);
  const [quizScore, setQuizScore] = useState(0);

  // Reset states when tutorial changes
  useEffect(() => {
    setActiveChapterIdx(0);
    setSandboxCode(tutorial.codeTemplate);
    setConsoleOutput([]);
    setSelectedAnswers({});
    setCheckedQuestions({});
    setQuizSubmitted(false);
    setShowSubmitForm(false);
    setSubmitSuccess(false);
  }, [tutorial]);

  const activeChapter = tutorial.chapters[activeChapterIdx];

  // Browser Code Runner
  const handleRunCode = () => {
    setIsRunning(true);
    setConsoleOutput(["Running tests..."]);

    setTimeout(() => {
      const logs: string[] = [];
      
      // Setup a safe sandbox environment to intercept console.log
      const originalLog = console.log;
      console.log = (...args: any[]) => {
        logs.push(args.map(arg => typeof arg === "object" ? JSON.stringify(arg, null, 2) : String(arg)).join(" "));
      };

      try {
        // Evaluate the code
        // To handle module import simulation or modern functions in ES, we strip standard imports and execute
        const cleanCode = sandboxCode.replace(/import\s+.*?;/g, "");
        
        // Execute inside a localized function wrapper to avoid global variables polution
        const runnable = new Function(cleanCode + "\n\n// Trigger checks if user defined test function\nif (typeof process_temperatures === 'function') {\n  console.log('Result for [25, -5, 0, 18, -12, 30]:', process_temperatures([25, -5, 0, 18, -12, 30]));\n} else if (typeof getUserProfile === 'function') {\n  getUserProfile(42).then(res => console.log('Mock Fetch Success for ID 42:', res));\n  getUserProfile(99).then(res => console.log('Mock Fetch Error handling for ID 99:', res));\n} else if (typeof useTimer === 'function') {\n  console.log('useTimer function is declared correctly.');\n} else {\n  console.log('Executed successfully with custom code structure.');\n}");
        runnable();
      } catch (err: any) {
        logs.push(`⚠️ Execution Error: ${err.message}`);
      } finally {
        console.log = originalLog;
      }

      setConsoleOutput(logs.length > 0 ? logs : ["Code ran successfully, but produced no standard logs."]);
      setIsRunning(false);
    }, 600);
  };

  const handleResetCode = () => {
    if (window.confirm("Are you sure you want to discard your changes and reset to the starting template?")) {
      setSandboxCode(tutorial.codeTemplate);
      setConsoleOutput([]);
    }
  };

  // Submit code for Peer Review
  const handleSubmitCode = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!userName.trim()) return;

    setIsSubmitting(true);
    try {
      const res = await fetch("/api/submissions", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          tutorialId: tutorial.id,
          tutorialTitle: tutorial.title,
          userName: userName.trim(),
          submittedCode: sandboxCode,
          userNotes: userNotes.trim()
        }),
      });

      if (res.ok) {
        setSubmitSuccess(true);
        setTimeout(() => {
          onSubmissionSuccess();
        }, 1500);
      } else {
        throw new Error("Failed to submit code");
      }
    } catch (err) {
      console.error(err);
      alert("Failed to submit code. Please verify server connection.");
    } finally {
      setIsSubmitting(false);
    }
  };

  // Quiz evaluation
  const handleQuizAnswer = (questionId: string, optionIdx: number) => {
    if (quizSubmitted) return;
    setSelectedAnswers((prev) => ({ ...prev, [questionId]: optionIdx }));
  };

  const checkIndividualAnswer = (questionId: string) => {
    setCheckedQuestions((prev) => ({ ...prev, [questionId]: true }));
  };

  const handleQuizSubmit = () => {
    let score = 0;
    tutorial.quiz.forEach((q) => {
      if (selectedAnswers[q.id] === q.correctAnswer) {
        score += 1;
      }
    });

    setQuizScore(score);
    setQuizSubmitted(true);

    // If passed (all correct), notify parent to mark completion
    if (score === tutorial.quiz.length) {
      onTutorialCompleted(tutorial.id);
    }
  };

  return (
    <div className="flex flex-col h-[calc(100vh-6.5rem)] animate-fade-in">
      {/* Top action header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 mb-4 border-b border-slate-200">
        <div className="flex items-center gap-3">
          <button
            onClick={onBack}
            className="p-2 border border-slate-200 text-slate-600 hover:text-slate-900 hover:bg-slate-50 rounded-lg transition-colors cursor-pointer"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 bg-indigo-50 text-indigo-700 text-[10px] font-bold rounded uppercase tracking-wider border border-indigo-100">
                {tutorial.category}
              </span>
              <span className="text-xs text-slate-400 font-semibold">100% Interactive</span>
            </div>
            <h2 className="font-extrabold text-slate-900 tracking-tight text-lg md:text-xl line-clamp-1 mt-0.5">
              {tutorial.title}
            </h2>
          </div>
        </div>

        {/* Chapter switch header for quick jump */}
        <div className="flex items-center gap-1.5">
          {tutorial.chapters.map((_, idx) => (
            <button
              key={idx}
              onClick={() => setActiveChapterIdx(idx)}
              className={`w-7 h-7 text-xs font-bold rounded-lg border transition-colors cursor-pointer ${
                activeChapterIdx === idx
                  ? "bg-indigo-600 text-white border-indigo-600 shadow-sm"
                  : "bg-white text-slate-500 border-slate-200 hover:bg-slate-50"
              }`}
            >
              {idx + 1}
            </button>
          ))}
        </div>
      </div>

      {/* Main Split Layout */}
      <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 gap-6 overflow-hidden min-h-0">
        
        {/* Left Section: Chapter Learning Reader */}
        <div className="lg:col-span-6 bg-white rounded-xl border border-slate-200 shadow-sm flex flex-col overflow-hidden">
          {/* Chapter Header */}
          <div className="px-5 py-4 bg-slate-50 border-b border-slate-200/60 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <BookOpen className="w-4 h-4 text-indigo-600" />
              <span className="text-xs font-bold text-slate-500 uppercase tracking-widest">
                Chapter {activeChapterIdx + 1}: {activeChapter.title}
              </span>
            </div>
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
              {activeChapterIdx + 1} of {tutorial.chapters.length}
            </span>
          </div>

          {/* Body Content */}
          <div className="flex-1 p-6 overflow-y-auto min-h-0">
            <Markdown>{activeChapter.content}</Markdown>
          </div>

          {/* Pagination Footer */}
          <div className="px-5 py-4 border-t border-slate-200 bg-slate-50/50 flex justify-between items-center">
            <button
              disabled={activeChapterIdx === 0}
              onClick={() => setActiveChapterIdx((prev) => prev - 1)}
              className="px-3.5 py-1.5 text-xs font-semibold border border-slate-200 text-slate-600 hover:text-slate-900 hover:bg-slate-50 rounded-lg transition-colors disabled:opacity-40 disabled:cursor-not-allowed flex items-center gap-1.5 cursor-pointer"
            >
              <ChevronLeft className="w-3.5 h-3.5" />
              Previous
            </button>

            <button
              disabled={activeChapterIdx === tutorial.chapters.length - 1}
              onClick={() => setActiveChapterIdx((prev) => prev + 1)}
              className="px-3.5 py-1.5 text-xs font-semibold bg-indigo-600 text-white hover:bg-indigo-700 rounded-lg transition-colors disabled:opacity-40 disabled:cursor-not-allowed flex items-center gap-1.5 cursor-pointer"
            >
              Next
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>


        {/* Right Section: Workspace (Interactive Sandbox & Quizzes) */}
        <div className="lg:col-span-6 flex flex-col gap-6 overflow-hidden">
          
          {/* Sub-Tabs: Code Sandbox vs Quiz */}
          <div className="flex-1 bg-white rounded-xl border border-slate-200 shadow-sm flex flex-col overflow-hidden">
            {/* Tab header */}
            <div className="px-3 py-2 bg-slate-50 border-b border-slate-200/60 flex items-center justify-between">
              <div className="flex items-center gap-1">
                <span className="text-xs font-bold px-3 py-1 bg-white text-slate-800 shadow-xs rounded-md border border-slate-200/60 flex items-center gap-1.5">
                  <Code className="w-3.5 h-3.5 text-indigo-600" />
                  Code Sandbox
                </span>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={handleResetCode}
                  title="Reset starting template"
                  className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>

            {/* Sandbox Area */}
            <div className="flex-1 flex flex-col min-h-0">
              {/* Code input */}
              <div className="flex-1 relative font-mono text-sm overflow-hidden bg-slate-900">
                <textarea
                  value={sandboxCode}
                  onChange={(e) => setSandboxCode(e.target.value)}
                  className="w-full h-full p-4 bg-transparent text-gray-200 focus:outline-none resize-none font-mono text-xs leading-relaxed overflow-y-auto"
                  placeholder="// Paste or write your coding solution here..."
                  spellCheck="false"
                />
              </div>

              {/* Console & Action buttons */}
              <div className="h-40 bg-slate-950 border-t border-slate-800 flex flex-col overflow-hidden">
                {/* Console header */}
                <div className="px-4 py-1.5 bg-slate-900 border-b border-slate-800 flex justify-between items-center text-slate-400 font-mono text-[10px] font-semibold tracking-wider uppercase">
                  <span>In-Browser Runner Terminal</span>
                  <span className="text-indigo-400">active console</span>
                </div>

                {/* Console output buffer */}
                <div className="flex-1 p-3 overflow-y-auto font-mono text-xs text-gray-300 space-y-1 bg-slate-950">
                  {consoleOutput.length === 0 ? (
                    <p className="text-slate-500 italic">Console output is empty. Press 'Run Code' to execute and debug.</p>
                  ) : (
                    consoleOutput.map((log, idx) => (
                      <pre key={idx} className="whitespace-pre-wrap break-all leading-relaxed">
                        {log}
                      </pre>
                    ))
                  )}
                </div>
              </div>
            </div>

            {/* Sandbox Action bar */}
            <div className="px-5 py-3 border-t border-slate-200 bg-slate-50 flex justify-between items-center">
              <button
                onClick={() => setShowSubmitForm(!showSubmitForm)}
                className="px-3.5 py-1.5 border border-slate-200 text-slate-700 hover:text-slate-900 bg-white hover:bg-slate-50 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
              >
                <Send className="w-3.5 h-3.5 text-slate-400" />
                Submit Peer Review
              </button>

              <button
                disabled={isRunning}
                onClick={handleRunCode}
                className="px-4 py-1.5 bg-indigo-600 text-white hover:bg-indigo-700 disabled:opacity-60 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors shadow-sm cursor-pointer"
              >
                <Play className="w-3.5 h-3.5 fill-indigo-200 text-white" />
                Run Code
              </button>
            </div>
          </div>

          {/* Submission drawer */}
          {showSubmitForm && (
            <div className="bg-white rounded-xl border border-indigo-100 p-5 shadow-md relative animate-fade-in space-y-4">
              <div className="flex justify-between items-center pb-2 border-b border-slate-100">
                <h4 className="font-bold text-slate-900 text-xs flex items-center gap-1.5 uppercase tracking-wide">
                  <Send className="w-3.5 h-3.5 text-indigo-600" />
                  Submit Solution for Review
                </h4>
                <button
                  onClick={() => setShowSubmitForm(false)}
                  className="text-slate-400 hover:text-slate-600 text-xs font-semibold cursor-pointer"
                >
                  Close
                </button>
              </div>

              {submitSuccess ? (
                <div className="py-6 flex flex-col items-center justify-center text-center space-y-2 animate-pulse">
                  <CheckCircle2 className="w-10 h-10 text-emerald-500" />
                  <h5 className="font-bold text-slate-900 text-sm">Submission Published!</h5>
                  <p className="text-slate-400 text-xs">Redirecting to Peer Review Board...</p>
                </div>
              ) : (
                <form onSubmit={handleSubmitCode} className="space-y-4">
                  <div>
                    <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1">
                      Your Student Display Name
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="e.g. MasterCoder_7"
                      value={userName}
                      onChange={(e) => setUserName(e.target.value)}
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 focus:border-indigo-500 rounded-lg outline-none font-sans text-xs text-slate-800 transition-colors"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1">
                      Explain Your Solution (Notes for Reviewers)
                    </label>
                    <textarea
                      placeholder="e.g. I implemented a robust check satisfy constraints..."
                      value={userNotes}
                      onChange={(e) => setUserNotes(e.target.value)}
                      rows={2}
                      className="w-full px-3 py-2 bg-slate-50 border border-slate-200 focus:border-indigo-500 rounded-lg outline-none font-sans text-xs text-slate-800 resize-none transition-colors"
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={isSubmitting || !userName.trim()}
                    className="w-full py-2 bg-indigo-600 text-white hover:bg-indigo-700 disabled:opacity-50 rounded-lg text-xs font-semibold transition-colors shadow-sm flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    {isSubmitting ? "Publishing..." : "Publish to Peer Review Board"}
                  </button>
                </form>
              )}
            </div>
          )}

          {/* Interactive Quiz Panel */}
          <div className="bg-white rounded-xl border border-slate-200 shadow-sm p-5 space-y-4">
            <div className="flex items-center gap-2 pb-2 border-b border-slate-100">
              <GraduationCap className="w-4.5 h-4.5 text-indigo-600" />
              <h3 className="font-extrabold text-slate-900 tracking-tight text-xs uppercase tracking-wider">Concept Check Quiz</h3>
            </div>

            <div className="space-y-5 overflow-y-auto max-h-64 pr-1">
              {tutorial.quiz.map((q, qIdx) => {
                const isAnswerChecked = checkedQuestions[q.id];
                const isCorrect = selectedAnswers[q.id] === q.correctAnswer;

                return (
                  <div key={q.id} className="space-y-2.5">
                    <p className="text-xs font-bold text-slate-800 flex items-start gap-1">
                      <span>{qIdx + 1}.</span>
                      <span>{q.question}</span>
                    </p>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                      {q.options.map((opt, optIdx) => {
                        const isSelected = selectedAnswers[q.id] === optIdx;
                        let optStyle = "bg-white border border-slate-200 text-slate-700 hover:border-indigo-300 shadow-xs";
                        
                        if (isSelected) {
                          optStyle = "bg-indigo-50/40 border-2 border-indigo-600 text-indigo-900 font-semibold ring-4 ring-indigo-50/50 shadow-xs";
                        }
                        if (isAnswerChecked) {
                          if (optIdx === q.correctAnswer) {
                            optStyle = "bg-emerald-50/40 border-2 border-emerald-600 text-emerald-950 font-bold";
                          } else if (isSelected && optIdx !== q.correctAnswer) {
                            optStyle = "bg-rose-50/40 border-2 border-rose-600 text-rose-950 font-medium";
                          }
                        }

                        return (
                          <button
                            key={optIdx}
                            type="button"
                            disabled={quizSubmitted || isAnswerChecked}
                            onClick={() => handleQuizAnswer(q.id, optIdx)}
                            className={`p-2.5 text-left text-[11px] rounded-lg border transition-all cursor-pointer ${optStyle}`}
                          >
                            {opt}
                          </button>
                        );
                      })}
                    </div>

                    {/* Explanations */}
                    {selectedAnswers[q.id] !== undefined && !isAnswerChecked && (
                      <button
                        onClick={() => checkIndividualAnswer(q.id)}
                        className="text-[10px] text-indigo-600 hover:text-indigo-800 font-bold cursor-pointer"
                      >
                        Check Answer
                      </button>
                    )}

                    {isAnswerChecked && (
                      <div className={`p-3 rounded-lg border text-[11px] leading-relaxed flex gap-2 items-start ${
                        isCorrect ? "bg-emerald-50/50 border-emerald-100 text-emerald-900" : "bg-rose-50/50 border-rose-100 text-rose-900"
                      }`}>
                        {isCorrect ? (
                          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                        ) : (
                          <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                        )}
                        <div>
                          <p className="font-bold mb-0.5">{isCorrect ? "Correct!" : "Incorrect"}</p>
                          <p className="text-slate-600 font-medium">{q.explanation}</p>
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>

            {/* Quiz Action / Grade Board */}
            <div className="pt-3 border-t border-slate-100 flex justify-between items-center">
              {quizSubmitted ? (
                <div className="flex items-center gap-3 w-full justify-between">
                  <div>
                    <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Graded Score</p>
                    <p className="text-xs font-bold text-slate-900">
                      {quizScore} of {tutorial.quiz.length} Correct ({Math.round((quizScore / tutorial.quiz.length) * 100)}%)
                    </p>
                  </div>
                  {quizScore === tutorial.quiz.length ? (
                    <span className="px-3 py-1 bg-emerald-50 text-emerald-700 text-[10px] font-bold rounded-lg flex items-center gap-1 border border-emerald-100 animate-pulse">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      Passed Module!
                    </span>
                  ) : (
                    <button
                      onClick={() => {
                        setSelectedAnswers({});
                        setCheckedQuestions({});
                        setQuizSubmitted(false);
                      }}
                      className="px-3 py-1.5 border border-slate-200 hover:bg-slate-50 text-slate-700 text-xs font-semibold rounded-lg cursor-pointer"
                    >
                      Try Again
                    </button>
                  )}
                </div>
              ) : (
                <button
                  onClick={handleQuizSubmit}
                  disabled={Object.keys(selectedAnswers).length < tutorial.quiz.length}
                  className="w-full py-2 bg-indigo-600 text-white hover:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed text-xs font-bold rounded-lg shadow-sm transition-colors cursor-pointer"
                >
                  Grade Entire Quiz
                </button>
              )}
            </div>
          </div>

        </div>
      </div>
    </div>
  );
}

export type Difficulty = 'Beginner' | 'Intermediate' | 'Advanced';

export interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctAnswer: number; // index in options
  explanation: string;
}

export interface Chapter {
  id: string;
  title: string;
  content: string; // Markdown supported
}

export interface Tutorial {
  id: string;
  title: string;
  description: string;
  category: string;
  difficulty: Difficulty;
  duration: string;
  chapters: Chapter[];
  codeTemplate: string;
  solutionCode: string;
  runInstructions: string;
  quiz: QuizQuestion[];
  isAICreated?: boolean;
}

export interface Review {
  id: string;
  reviewerName: string;
  ratingCorrectness: number; // 1-5
  ratingReadability: number; // 1-5
  ratingArchitecture: number; // 1-5
  comments: string; // Markdown supported
  createdAt: string;
  isAI?: boolean;
}

export interface Submission {
  id: string;
  tutorialId: string;
  tutorialTitle: string;
  userName: string;
  submittedCode: string;
  userNotes: string;
  createdAt: string;
  reviews: Review[];
}
